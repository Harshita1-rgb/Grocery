
package com.example.grocery;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.grocery.GroceryAdapter;
import com.example.grocery.GroceryItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView listViewGroceries;
    private GroceryAdapter adapter;
    private ArrayList<GroceryItem> groceriesList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listViewGroceries = findViewById(R.id.list);
        initArrayList();
        adapter = new GroceryAdapter(this, groceriesList);
        listViewGroceries.setAdapter(adapter);
        listViewGroceries.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                GroceryItem groceryItem = adapter.getItem(position);
                Toast.makeText(MainActivity.this, groceryItem.getName(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

    }

    private void initArrayList() {
        groceriesList.clear();
        groceriesList.add(new GroceryItem("potato", R.drawable.potato));  // potato.png in res/drawable
        groceriesList.add(new GroceryItem("onion", R.drawable.onion));    // onion.png in res/drawable
        groceriesList.add(new GroceryItem("apple", R.drawable.apple));    // apple.png in res/drawable
        groceriesList.add(new GroceryItem("carrot", R.drawable.carrot));  // carrot.png in res/drawable
        groceriesList.add(new GroceryItem("lettuce", R.drawable.lettuce)); // lettuce.png in res/drawable
        groceriesList.add(new GroceryItem("tomato", R.drawable.tomato));   // tomato.png in res/drawable
        groceriesList.add(new GroceryItem("garlic", R.drawable.garlic));   // garlic.png in res/drawable
        groceriesList.add(new GroceryItem("spinach", R.drawable.spinach)); // spinach.png in res/drawable

// Notify the adapter if needed
        adapter.notifyDataSetChanged();

    }
}